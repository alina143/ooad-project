import socket
from journalDB import *
from threading import Thread
import pickle

journalPatient = None
journalDoctor = None
journalAdmin = None

dbname, dbuser = 'postgres', 'alinapopova'


def authorization(clsock):
    while True:
        usr_info = clsock.recv(1000)
        if checkUser(usr_info):
            clsock.send(bytes("correct", 'utf8'))

            break
        else:

            clsock.send(bytes("incorrect", 'utf8'))


def reciveMessage(clsock):
    authorization(clsock)
    while True:
        command = clsock.recv(1000)
        if len(command) == 0:
            clsock.close()
        else:
            if "!disconnect" == command.decode():
                clsock.close()
                break
            else:
                handleCommand(command, clsock)


def handleCommand(cmd, sock):
    full_command = cmd.decode().split(' ')
    if full_command[0] == 'patient':
        data = execPatientCmd(full_command[1:], sock)
        sendData(data, sock)
    elif full_command[0] == 'doctor':
        data = execDoctorCmd(full_command[1:], sock)
        sendData(data, sock)
    elif full_command[0] == 'admin':
        data = execAdminCmd(full_command[1:], sock)
        sendData(data, sock)


def sendData(data, sock):
    if data.data is None:
        data.data = 'Incorrect amount of parameters'
        sock.send(pickle.dumps(data.data))
    else:
        toSend = pickle.dumps(data.data)
        sock.send(pickle.dumps(str(len(toSend)) + ' ' + data.type_of_response))
        sock.recv(50)
        sock.send(toSend)


def execPatientCmd(command, sock):
    data = None

    if command[0] == 'results':
        if len(command) == 3:
            analysis, patient = command[1], command[2]
            data = journalPatient.viewResults(patient=patient, analysis=analysis)
            data.type_of_response = 'results'
        elif len(command) == 2:
            patient = command[1]
            data = journalPatient.viewResults(patient=patient)
            data.type_of_response = 'results'

    elif command[0] == 'area':
        if len(command) == 3:
            area_name = command[1]
            data = journalPatient.viewArea(area_name=area_name)
            data.type_of_response = 'patients' if type(data.data) == list else 'message'

    elif command[0] == 'doctors':
        if len(command) == 2:
            data = journalPatient.viewDoctors()
            data.type_of_response = 'doctors'

        if len(command) == 3:
            analysis = command[1]
            data = journalPatient.viewdoctors(analysis=analysis)
            data.type_of_response = 'doctors' if type(data.data) == list else 'message'

    elif command[0] == 'shedule':
        if len(command) == 2:
            data = journalPatient.viewDoctorShedule()
            data.type_of_response = 'shedule' if type(data.data) == list else 'message'

    elif command[0] == 'history':
        if len(command) == 2:
            login = command[1]
            data = journalPatient.viewAppointmentHistory(login)
            data.type_of_response = 'history' if type(data.data) == list else 'message'

    elif command[0] == 'appointment':
        if len(command) == 4:
            time, doctor, patient = command[1], command[2], command[3]
            data = journalPatient.makeAppointment(time, doctor, patient)
            data.type_of_response = 'message'

    elif command[0] == 'cancel_appointment':
        if len(command) == 4:
            time, doctor, login = command[1], command[2], command[3]
            data = journalPatient.cancelAppointment(time, doctor, login)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'change_password':
        if len(command) == 3:
            password, login = command[1], command[2]
            data = journalPatient.changePassword(login, password)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    else:
        data.data = 'Unknown command!'
        data.type_of_response = 'message'

    return data


def execDoctorCmd(command, sock):
    data = None

    if command[0] == 'set_result':
        if len(command) == 9:
            names, area_name, result, date, analysis, doctor = command[1:4], command[4], command[5], command[6], \
                                                               command[7], command[8]
            data = journalDoctor.addResults(names, analysis, date, area_name, result, doctor)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'edit_result':
        if len(command) == 9:
            names, area_name, result, date, analysis, doctor = command[1:4], command[4], command[5], command[6], \
                                                               command[7], command[8]
            data = journalDoctor.editResult(names, analysis, date, area_name, result, doctor)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'remove_result':
        if len(command) == 8:
            names, area_name, date, analysis, doctor = command[1:4], command[4], command[5], command[6], command[7]
            data = journalDoctor.removeResult(names, analysis, date, area_name, doctor)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'patients':
        if len(command) == 3:
            area_name = command[1]
            data = journalDoctor.viewPatients(area_name)
            data.type_of_response = 'patients'

    elif command[0] == 'doctors':
        if len(command) == 2:
            data = journalDoctor.viewDoctors()
            data.type_of_response = 'doctors'
        elif len(command) == 3:
            analysis = command[1]
            data = journalDoctor.viewDoctors(analysis)
            data.type_of_response = 'doctors' if type(data.data) == list else 'message'

    elif command[0] == 'area_results':
        if len(command) == 4:
            analysis, area_name, doctor = command[1], command[2], command[3]
            data = journalDoctor.viewAreaResults(analysis, area_name, doctor)
            data.type_of_response = 'results' if type(data.data) == list else 'message'

        elif len(command) == 6:
            analysis, area_name, start_date, end_date, doctor = command[1], command[2], command[3], command[4], command[
                5]
            data = journalDoctor.viewAreaResults(analysis, area_name, doctor, start_date=start_date, end_date=end_date)
            data.type_of_response = 'results' if type(data.data) == list else 'message'

    elif command[0] == 'change_password':
        if len(command) == 3:
            password, login = command[1], command[2]
            data = journalDoctor.changePassword(login, password)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    else:
        data.data = 'Unknown command!'
        data.type_of_response = 'message'

    return data


def execAdminCmd(command, sock):
    data = None

    if command[0] == 'add_doctor':
        if len(command) >= 8:
            names, login, password, analysis = command[1:4], command[4], command[5], command[6:len(command) - 1]
            data = journalAdmin.addDoctor(names, login, password, analysis)
            print(type(data.data))
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'add_patient':
        if len(command) == 8:
            names, login, password, area_name = command[1:4], command[4], command[5], command[6]
            data = journalAdmin.addPatient(names, login, password, area_name)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'add_analysis':
        if len(command) == 3:
            analysis = command[1]
            data = journalAdmin.addAnalysis(analysis)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'add_area':
        if len(command) == 4:
            area_name, area_doctor = command[1], command[2]
            data = journalAdmin.addArea(area_name, area_doctor)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'set_doctor':
        if len(command) == 5:
            area_name, area_doctor, analysis = command[1], command[2], command[3]
            data = journalAdmin.setDoctorArea(area_doctor, area_name, analysis)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'add_doctor_analysis':
        if len(command) == 4:
            doctor, analysis = command[1], command[2]
            data = journalAdmin.addDoctorAnalysis(doctor, analysis)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'remove_patient':
        if len(command) == 4:
            login, dependencies = command[1], command[2]
            data = journalAdmin.removePatient(login, dependencies)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'remove_doctor':
        if len(command) == 4:
            login, dependencies = command[1], command[2]
            data = journalAdmin.removeDoctor(login, dependencies)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'remove_analysis':
        if len(command) == 4:
            analysis, dependencies = command[1], command[2]
            data = journalAdmin.removeAnalysis(analysis, dependencies)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'remove_area':
        if len(command) == 4:
            area_name, dependencies = command[1], command[2]
            data = journalAdmin.removeArea(area_name, dependencies)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'remove_results':
        if len(command) == 3:
            area_name = command[1]
            data = journalAdmin.removeResults(area_name)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'change_patient_area':
        if len(command) == 4:
            login, newArea = command[1], command[2]
            data = journalAdmin.changePatientArea(login, newArea)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'rename_area':
        if len(command) == 4:
            oldArea, newArea = command[1], command[2]
            data = journalAdmin.renameArea(oldArea, newArea)
            data.data = 'Incorrect values!' if not type(data.data) == str else data.data
            data.type_of_response = 'message'

    elif command[0] == 'change_password':
        if len(command) == 3:
            password, login = command[1], command[2]
            data = journalAdmin.changePassword(login, password)
            data.type_of_response = 'message'

    else:
        data.data = 'Unknown command!'
        data.type_of_response = 'message'

    return data


def checkUser(auth):
    global journalPatient, journalDoctor, journalAdmin, dbname, dbuser
    usr_info = auth.decode('utf8').split('~')
    if usr_info[0] == 'patient':
        journalPatient = PatientJournal(dbname, dbuser)
        return journalPatient.checkUser(usr_info[1], usr_info[2])
    elif usr_info[0] == 'doctor':
        journalDoctor = DoctorJournal(dbname, dbuser)
        return journalDoctor.checkUser(usr_info[1], usr_info[2])
    elif usr_info[0] == 'admin':
        journalAdmin = Administrator(dbname, dbuser)
        return journalAdmin.checkUser(usr_info[1], usr_info[2])


MAX_CLIENTS = 10
address = ('localhost', 8080)

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.bind(address)
sock.listen(MAX_CLIENTS)

while True:
    try:
        conn, addr = sock.accept()
        print(conn)
        threadRecv = Thread(target=reciveMessage, args=(conn,))
        threadRecv.start()
    except KeyboardInterrupt:
        sock.close()
