import psycopg2

conn = psycopg2.connect(dbname='postgres', user='alinapopova',
                        password='abpbrf17', host='localhost')
cursor = conn.cursor()

cursor.execute(''' drop table if exists patients, account, doctors, areas, analyzes, doctor_analysis, results, area_list, doctor_shedule, appointment_history ''')


cursor.execute(''' drop trigger if exists del_trigger on patients ''')
cursor.execute(''' drop trigger if exists del_trigger on doctors ''')
cursor.execute(''' drop trigger if exists history_trigger on doctors ''')
cursor.execute(''' drop function  deleteFromAccounts() cascade ''')
cursor.execute(''' drop function if exists updateAreas() ''')
cursor.execute(''' drop function if exists updateAppointmentHistory() ''')


# ============= O K ============= #
cursor.execute(''' create table if not exists account(
    login varchar(30) primary key,
    password varchar(30) not null,
    status varchar(30) not null
)''')

cursor.execute(''' insert into account values 
('ivanova1', '123', 'patient'),
 ('ivanova2', '123', 'patient'),
 ('smirnova1', '123', 'patient'),
 ('sidorova1', '123', 'doctor'),
 ('revina1', '123', 'doctor'),
 ('belkina1', '123', 'doctor')''')


cursor.execute(''' create table if not exists patients(
    login varchar(30) primary key,
    surname varchar(30) not null,
    name varchar(30) not null,
    patronymic varchar(30) not null,
    foreign key (login) references account(login)
) ''')

cursor.execute(''' create table if not exists doctors(
    login varchar(30) primary key,
    surname varchar(30) not null,
    name varchar(30) not null,
    patronymic varchar(30) not null,
    foreign key (login) references account(login)
) ''')

cursor.execute(''' create table if not exists areas(
    area varchar(3) primary key,
    area_doctor varchar(30)
) ''')

cursor.execute(''' create table if not exists analyzes(
    analysis varchar(30) primary key
) ''')

cursor.execute(''' create table if not exists doctor_analysis(
    id serial primary key,
    doctor varchar(30) not null,
    analysis varchar(30) not null,
    foreign key (doctor) references doctors(login),
    foreign key (analysis) references analyzes(analysis)
) ''')



cursor.execute(''' create table if not exists area_list(
    patient varchar(30) primary key,
    area varchar(3) not null,
    foreign key (area) references areas(area),
    foreign key (patient) references patients(login)
) ''')

cursor.execute(''' create table if not exists results(
    id serial primary key,
    patient varchar not null,
    analysis varchar(30) not null,
    area varchar(3) not null,
    date date not null,
    result int not null,
    foreign key (patient) references patients(login),
    foreign key (area) references areas(area),
    foreign key (analysis) references analyzes(analysis)

) ''')

cursor.execute(''' create table if not exists doctor_shedule(
    doctor varchar(30) not null,
    time time not null,
    state varchar(30) not null,
    foreign key (doctor) references doctors(login),
    CONSTRAINT doctor_time PRIMARY KEY(doctor,time)
) ''')

cursor.execute('''insert into doctors values 
('sidorova1', 'sidorova', 'nadezda', 'petrovna'),
 ('revina1', 'revina', 'oksana', 'timoffevna'),
 ('belkina1', 'belkina', 'svetlana', 'borisovna')''')

cursor.execute('''insert into doctor_shedule values 
('sidorova1', '10:00:00' , 'available'),
('sidorova1', '10:30:00', 'available'),
('sidorova1', '11:00:00', 'available'),
('sidorova1', '11:30:00', 'available'),
('revina1', '14:00:00', 'available'),
('revina1', '14:30:00', 'available'),
('revina1', '15:00:00', 'available'),
('belkina1', '17:30:00', 'available'),
('belkina1', '18:00:00', 'available'),
('belkina1', '18:30:00', 'available')''')

cursor.execute(''' create table if not exists appointment_history(
    doctor varchar(30) not null,
    time time not null,
    patient varchar(30) not null,
    CONSTRAINT doctor_time2 PRIMARY KEY(doctor,time),
    foreign key (doctor) references doctors(login),
    foreign key (patient) references patients(login))''')

cursor.execute(''' insert into patients values 
('ivanova1', 'ivanova', 'irina', 'petrovna'),
('ivanova2', 'ivanova', 'olga', 'alexeevna'),
('smirnova1', 'smirnova', 'vera', 'olegovna')''')



cursor.execute('''insert into areas values 
('1', 'sidorova1'),
 ('2', 'revina1'),
 ('3', 'belkina1')''')

cursor.execute('''insert into analyzes values 
('vitaminE') ,
('vitaminA'),
('vitaminB'),
('vitaminD'),
('globulin'),
('saxar'),
('gemoglobin'),
('vich'),
('spid')''')

cursor.execute('''insert into area_list values 
('ivanova1', '1'),
('ivanova2', '1'),
('smirnova1', '2')''')

cursor.execute('''insert into doctor_analysis values 
(1, 'sidorova1', 'vitaminE'),
(2, 'sidorova1', 'vitaminA'),
(3, 'sidorova1', 'vitaminB'),
(4, 'sidorova1', 'vitaminD'),
(5, 'revina1', 'globulin'),
(6, 'revina1', 'saxar'),
(7, 'revina1', 'gemoglobin'),
(8, 'belkina1', 'vich'),
(9, 'belkina1', 'spid')''')

cursor.execute('''insert into results values 
( 1, 'ivanova1', 'vitaminE','1', '2018-01-20', 5),
(2,  'ivanova1', 'vitaminA', '1','2018-01-20', 10),
(3,  'ivanova2', 'vitaminB','1' ,'2018-01-20', 6),
( 4, 'smirnova1', 'saxar','2', '2018-01-20', 80)''')

cursor.execute(''' 
create or replace function deleteFromAccounts() returns trigger as
$$
begin
  delete from account where login = old.login;
  return old;
end;
$$
language plpgsql
''')

cursor.execute(''' 
create or replace function updateAppointmentHistory() returns trigger as
$$
begin
    IF (TG_OP = 'INSERT') THEN
        UPDATE doctor_shedule SET state = 'not available' where doctor = NEW.doctor and time = NEW.time;
    ELSIF(TG_OP = 'DELETE') THEN
         UPDATE doctor_shedule SET state = 'available' where doctor = OLD.doctor and time = OLD.time;
    END IF;
RETURN NULL;
end;
$$
language plpgsql
''')

cursor.execute(''' 
create trigger history_trigger
    after delete or insert
    on appointment_history
    for each row
execute procedure updateAppointmentHistory()
 ''')

cursor.execute(''' 
create trigger del_trigger
    after delete
    on patients
    for each row
execute procedure deleteFromAccounts()
 ''')

cursor.execute(''' 
create trigger del_trigger
    after delete
    on doctors
    for each row
execute procedure deleteFromAccounts()
 ''')

#cursor.execute('''  ''')

# ============= O K ============= #

conn.commit()

#print(cursor.fetchall())
