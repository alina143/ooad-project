import socket
import pickle

serverAddress = ('localhost', 8080)
users = ['patient', 'doctor', 'admin']
login = ''
usr = ''

patient_commands = ['results',
                    'area',
                    'doctors',
                    'history',
                    'shedule',
                    'appointment',
                    'cancel_appointment',
                    '!disconnect']

doctor_commands = ['set_result',
                   'edit_result',
                   'patients',
                   'doctors',
                   'area_results',
                   'remove_result',
                   '!disconnect']

admin_commands = ['add_doctor',
                  'add_patient',
                  'add_analysis',
                  'add_area',
                  'set_doctor',
                  'add_doctor_analysis',
                  'remove_patient',
                  'remove_doctor',
                  'remove_analysis',
                  'remove_area',
                  'remove_results',
                  'change_password',
                  'change_patient_area',
                  'rename_area',
                  '!disconnect']

parametrs_AdminCommand = {
    'add_doctor': 'surname name patronymic login password analyzes[]',
    'add_patient': 'surname name patronymic login password area',
    'add_analysis': 'analysis',
    'add_area': 'area area_doctor',
    'set_doctor': 'area doctor analysis',
    'add_doctor_analysis': 'doctor analysis',
    'remove_patient': 'login dependencies',
    'remove_doctor': 'login dependencies',
    'remove_analysis': 'analysis dependencies',
    'remove_area': 'area dependencies',
    'remove_results': 'area',
    'change_password': 'newPassword',
    'change_patient_area': 'login newArea',
    'rename_area': 'oldArea newArea',
    '!disconnect': '-'
}

parametrs_PatientCommand = {
    'results': 'analysis',
    'area': 'area_name',
    'doctors': '- OR analysis',
    'history': 'login',
    'shedule': '-',
    'appointment': 'time doctor login',
    'cancel_appointment': 'time doctor login',
    '!disconnect': '-'
}

parametrs_DoctorCommand = {
    'set_result': 'surname name patronymic area result date analysis',
    'edit_result': 'surname name patronymic area result date analysis',
    'patients': 'area',
    'doctors': 'analysis OR -',
    'area_results': 'analysis area OR analysis area start_date end_date',
    'remove_result': 'surname name patronymic area date analysis',
    '!disconnect': '-'
}

usage_admin = {
    'add_doctor': 'add new doctor to database and set his/her analysis',
    'add_patient': 'add new patient to database and sets him/her to the area',
    'add_analysis': 'add new analysis to database',
    'add_area': 'add new area with area doctor',
    'set_doctor': 'set doctor to give analysis for a specific area',
    'add_doctor_analysis': 'add new analysis to doctor',
    'remove_patient': 'delete patient (if second param = 0) OR delete at first all dependencies (if second param = 1)',
    'remove_doctor': 'delete doctor (if second param = 0) OR delete at first all dependencies (if second param = 1)',
    'remove_analysis': 'delete analysis (if second param = 0) OR delete at first all dependencies (if second param = 1)',
    'remove_area': 'delete area (if second param = 0) OR delete at first all dependencies (if second param = 1)',
    'remove_results': 'remove all results of the area',
    'change_password': 'change password',
    'change_patient_area': 'change area for patient',
    'rename_area': 'rename area',
    '!disconnect': 'exit'
}

usage_patient = {
    'results': 'show all results by analysis',
    'area': 'show patients in the area',
    'doctors': 'show all doctor OR show doctor by analysis',
    'shedule': 'show doctors shedule',
    'history': 'show your appointment history',
    'appointment': 'You can choose available time and doctor and make an appointment',
    'cancel_appointment': 'You can cancel your reception',
    '!disconnect': 'exit'
}

usage_doctor = {
    'set_result': 'set result',
    'edit_result': 'edit result',
    'patients': 'show all patients in the area',
    'doctors': 'show all doctors',
    'area_results': 'show all results in the area',
    'remove_result': 'delete result',
    '!disconnect': 'exit'
}


def showAvailableCommands():
    count = 0
    if usr == 'patient':
        for cmd in patient_commands:
            print(str(count) + ')' + 'COMMAND_NAME: ' + cmd + ' PARAMETERS: ' + parametrs_PatientCommand[cmd])
            print('  NOTE: ' + usage_patient[cmd])
            count += 1
            print()

    elif usr == 'doctor':
        for cmd in doctor_commands:
            print(str(count) + ')' + 'COMMAND_NAME: ' + cmd + ' PARAMETERS: ' + parametrs_DoctorCommand[cmd])
            print('  NOTE: ' + usage_doctor[cmd])
            count += 1
            print()

    elif usr == 'admin':
        for cmd in admin_commands:
            print(str(count) + ')' + 'COMMAND_NAME: ' + cmd + ' PARAMETERS: ' + parametrs_AdminCommand[cmd])
            print('  NOTE: ' + usage_admin[cmd])
            count += 1
            print()


def authorization():
    global login, usr, users, serverAddress
    while True:
        usr = input('Enter your status (patient/doctor/admin): ').lower()
        if usr not in users:
            print('Incorrect status. Try again!')
            continue

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(serverAddress)

        login = input("Enter login: ")
        passwd = input("Enter password: ")
        auth = usr + '~' + login + '~' + passwd
        s.send(bytes(auth, 'utf8'))
        data = s.recv(1000)
        if data.decode('utf8') == 'correct':
            print('Correct!')
            return s
        else:
            s.close()
            print('Incorrect login or password. Try again!')


def disconnect(sock):
    global login
    print("closed " + login)
    sock.close()
    exit(0)


def showResponse(sock, resp):
    response = resp.split(' ')
    if response[1] == 'message':
        sizeOfResponse = int(response[0])
        sock.send(pickle.dumps('ok'))
        data = sock.recv(sizeOfResponse)
        print(pickle.loads(data))

    elif response[1] == 'results':
        sizeOfResponse = int(response[0])
        sock.send(pickle.dumps('ok'))
        data = sock.recv(sizeOfResponse)
        results = pickle.loads(data)
        arr = ['Surname     ', 'Name      ', 'Patronymic      ', 'result ', 'analysis  ', 'date   ']
        print('Surname     | Name     | Patronymic     | Result | Analysis | Date(Y-M-D)')
        print('------------+----------+----------------+-------+---------+------------+')
        for i in range(len(results)):
            for j in range(6):
                print(results[i][j], end=((len(arr[j]) - len(str(results[i][j]))) * ' ') + '|')
            print()
    elif response[0] == 'Incorrect':
        print('Incorrect amount of parameters')
    elif response[1] == 'patients':
        sizeOfResponse = int(response[0])
        sock.send(pickle.dumps('ok'))
        data = sock.recv(sizeOfResponse)
        patients = pickle.loads(data)
        arr = [' Surname     ', 'Name       ', 'Patronymic ']
        print('Surname      | Name      | Patronymic')
        print('-------------+-----------+-----------')
        for i in range(len(patients)):
            for j in range(3):
                print(patients[i][j], end=((len(arr[j]) - len(str(patients[i][j]))) * ' ') + '|')
            print()

    elif response[1] == 'doctors':
        sizeOfResponse = int(response[0])
        sock.send(pickle.dumps('ok'))
        data = sock.recv(sizeOfResponse)
        doctors = pickle.loads(data)
        arr = [' Surname         ', 'Name          ', 'Patronymic       ', 'Analysis     |']
        print('Surname          | Name         | Patronymic      | Analysis      ')
        print('-----------------+--------------+-----------------+---------------')
        for i in range(len(doctors)):
            for j in range(4):
                print(doctors[i][j], end=((len(arr[j]) - len(str(doctors[i][j]))) * ' ') + '|')
            print()

    elif response[1] == 'shedule':
        sizeOfResponse = int(response[0])
        sock.send(pickle.dumps('ok'))
        data = sock.recv(sizeOfResponse)
        shedule = pickle.loads(data)
        arr = [' Doctor         ', 'Time          ', 'State       ']
        print('Doctor          | Time         | State         ')
        print('----------------+--------------+---------------')
        for i in range(len(shedule)):
            for j in range(3):
                print(shedule[i][j], end=((len(arr[j]) - len(str(shedule[i][j]))) * ' ') + '|')
            print()

    elif response[1] == 'history':
        sizeOfResponse = int(response[0])
        sock.send(pickle.dumps('ok'))
        data = sock.recv(sizeOfResponse)
        history = pickle.loads(data)
        arr = [' Doctor         ', 'Time          ']
        print('Doctor          | Time         ')
        print('----------------+--------------')
        for i in range(len(history)):
            for j in range(2):
                print(history[i][j], end=((len(arr[j]) - len(str(history[i][j]))) * ' ') + '|')
            print()


def handleCommand(sock, command):
    if command == "!disconnect":
        sock.send(bytes(command, 'utf8'))
        disconnect(sock)
    elif command == 'commands':
        showAvailableCommands()
    else:
        cmd = usr + ' ' + command + ' ' + login
        sock.send(bytes(cmd, 'utf8'))
        data = sock.recv(1000)
        showResponse(sock, pickle.loads(data))


s = authorization()

print(' ______________________________________')
print('|                                      |')
print('| To see all commands enter "commands" |')
print('|______________________________________|')
print()

try:
    while True:
        print()
        cmd = input('# ')
        handleCommand(s, cmd)

except KeyboardInterrupt:
    s.send(bytes('!disconnect', 'utf8'))
    disconnect(s)

s.close()
