import psycopg2
from datetime import datetime

class Data:
    def __init__(self, data, type):
        self.data = data
        self.type_of_response = type

class DoctorJournal:

    def __init__(self, dbname, username):
        self.conn = psycopg2.connect(dbname='postgres', user='alinapopova',
                                     password='abpbrf17', host='localhost')

        self.cursor = self.conn.cursor()

    def checkUser(self, login, passwd):
        self.cursor.execute(''' select password from account
                            where login = '%s' and status = 'doctor' '''
                            % login)

        password = self.cursor.fetchone()
        return False if password is None or password[0] != passwd else True

    def viewPatients(self, area_name):
        self.cursor.execute(''' select surname, name, patronymic from patients
                                where login in (select patient from area_list where area = '%s') 
                            ''' % area_name)
        dat = self.cursor.fetchall()
        data = Data(dat,  None)
        return data

    def viewAreaResults(self, analysis, area_name, doctor, start_date=None, end_date=None):

        if self.__isDoctorAreaAndAnalysis__(doctor, area_name, analysis):

            if end_date is None: end_date = str(datetime.today().strftime('%Y-%m-%d'))
            if start_date is None:
                start_date = str(datetime.today().strftime('%Y'))
                start_date += '-01-01' if int(datetime.today().strftime('%m')) <= 8 else '-09-01'

            self.cursor.execute(''' 
                                select pat.surname, pat.name, pat.patronymic, result, analysis, date 
                                from results res, patients pat
                                where analysis = '%s' and area = '%s' 
                                and res.date between '%s' and '%s' and pat.login = pat.patient
                                order by res.date
                                ''' % (analysis, area_name, start_date, end_date))

            dat = self.cursor.fetchall()
            data = Data(dat, None)
            return data
        data = Data('It\'s not your analysis', None)
        return data



    def addResult(self, names, analysis, date, area_name, result, doctor):
        try:
            if self.__isDoctorAreaAndAnalysis__(doctor, area_name, analysis):
                out = self.__getPatientLogin__(names, area_name)
                if out and 0 <= int(result) <= 100 and date <= str(datetime.today().strftime('%Y-%m-%d')):
                    login = out[0][0]
                    if not self.__resultExists__(login, analysis, date):
                        self.cursor.execute(''' insert into results(patient, analysis, area, date, result) values
                                                ('%s', '%s', '%s', '%s', %s)'''
                                            % (login, analysis, area_name, date, result))
                        self.conn.commit()
                        data = Data('New result added', None)
                        return data
                    data = Data('Result already exists. Use edit_result command!', None)
                    return data
                data = Data('Incorrect data', None)
                return data
            data = Data('it\'s not your analysis', None)
            return data

        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def editResult(self, names, analysis, date, area_name, result, doctor):
        try:
            if self.__isDoctorAreaAndAnalysis__(doctor, area_name, analysis):
                out = self.__getPatientLogin__(names, area_name)
                if out and 2 <= int(result) <= 5 and date <= str(datetime.today().strftime('%Y-%m-%d')):
                    login = out[0][0]
                    if self.__resultExists__(login, analysis, date):
                        self.cursor.execute(''' update results
                                                set result = %s 
                                                where patient='%s' and analysis='%s' and date='%s' and area='%s'
                                            ''' % (result, login, analysis, date, area_name))
                        self.conn.commit()
                        return Data('Result replaced', None)
                    return Data('Result doesn\'t exist!', None)
                return Data('Incorrect data', None)
            return Data('it\'s not your analysis', None)

        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def removeResult(self, names, analysis, date, area_name, doctor):
        try:
            if self.__isDoctorAreaAndAnalysis__(doctor, area_name, analysis):
                out = self.__getPatientLogin__(names, area_name)
                if out and date <= str(datetime.today().strftime('%Y-%m-%d')):
                    login = out[0][0]
                    if self.__resultExists__(login, analysis, date):
                        self.cursor.execute(''' delete from results 
                                            where patient='%s' and analysis='%s' and date='%s' and area='%s'
                                            ''' % (login, analysis, date, area_name))
                        self.conn.commit()
                        return Data('Result deleted', None)
                    return Data('Result doesn\'t exist!', None)
                return Data('Incorrect data', None)
            return Data('it\'s not your analysis', None)


        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def viewDoctors(self, analysis=None):
        if analysis is None:
            self.cursor.execute(''' select doc.surname, doc.name, doc.patronymic, cour.analysis
                                from doctors doc, doctor_analysis cour 
                                where cour.doctor = doc.login
                                ''')

            dat = self.cursor.fetchall()
            data = Data(dat, None)
            return data
        if self.__analysisExists__(analysis):
            self.cursor.execute(''' select doc.surname, doc.name, doc.patronymic, cour.analysis
                                    from doctors doc, doctor_analysis cour 
                                    where cour.doctor = doc.login and analysis = '%s' ''' % analysis)
            dat = self.cursor.fetchall()
            data = Data(dat, None)
            return data
        return Data('Analysis does not exist', None)

    def changePassword(self, login, newPassword):
        try:
            if not newPassword.isalnum():
                return 'Incorrect format'
            self.cursor.execute(''' update account set password='%s' where login='%s' ''' % (newPassword, login))
            self.conn.commit()
            return Data('changed!', None)

        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def __getPatientLogin__(self, names, area_name):
        data = [area_name] + names
        self.cursor.execute(''' select patient from area_list 
                            where area='%s' and patient in 
                            (select login from patients where surname='%s' and name='%s' and patronymic='%s') 
                            ''' % (tuple(data)))

        dat = self.cursor.fetchall()
        data = Data(dat, None)
        return data

    # def __isDoctorAreaAndAnalysis__(self, doctor, area_name, analysis):
    #   self.cursor.execute(''' select true from class_analyzes
    #                      where doctor='%s' and area='%s' and analysis='%s' ''' %
    #                     (doctor, area_name, analysis))

    # return True if self.cursor.fetchall() else False

    def __resultExists__(self, patient, analysis, date):
        self.cursor.execute(''' select result from results
                            where patient='%s' and analysis='%s' and date='%s' '''
                            % (patient, analysis, date))
        return True if self.cursor.fetchall() else False

    def __areaExists__(self, area_name):
        self.cursor.execute(''' select area from areas where area='%s' ''' % area_name)
        return True if self.cursor.fetchone() else False

    def __analysisExists__(self, analysis):
        self.cursor.execute(''' select analysis from analyzes where analysis='%s' ''' % analysis)
        return True if self.cursor.fetchone() else False


class PatientJournal:

    def __init__(self, dbname, username):
        self.conn = psycopg2.connect(dbname=dbname, user=username,
                                     password='', host='localhost')

        self.cursor = self.conn.cursor()

    def checkUser(self, login, passwd):
        self.cursor.execute(''' select password from account
                                where login = '%s' and status = 'patient' '''
                            % login)

        password = self.cursor.fetchone()
        print(password)
        print(login)
        return False if password is None or password[0] != passwd else True

    def viewResults(self, patient, analysis=None, start_date=None, end_date=None):

        if end_date is None: end_date = str(datetime.today().strftime('%Y-%m-%d'))
        if start_date is None:
            start_date = str(datetime.today().strftime('%Y'))
            start_date += '-01-01' if int(datetime.today().strftime('%m')) <= 8 else '-09-01'

        if analysis is None:
            self.cursor.execute(''' select pat.surname, pat.name, pat.patronymic, res.result, res.analysis, res.date 
                                from results res, patients pat
                                where res.patient = '%s' and  pat.login = res.patient
                                ''' % (patient))

            dat = self.cursor.fetchall()
            data = Data(dat, None)
            return data

        self.cursor.execute(''' select pat.surname, pat.name, pat.patronymic, res.result, res.analysis, res.date
                            from results res, patients pat
                            where res.analysis = '%s' and pat.login = res.patient and res.patient = '%s'
                            order by res.date 
                            ''' % (analysis, patient))

        dat = self.cursor.fetchall()
        data = Data(dat, None)
        return data

    def viewArea(self, area_name):
        if self.__areaExists__(area_name):
            self.cursor.execute(''' select surname, name, patronymic from patients
                                where login in (select patient from area_list where area = '%s') '''
                                % area_name)
            dat = self.cursor.fetchall()
            data = Data(dat, None)
            return data
        return Data('Area does not exist', None)

    def viewDoctors(self, analysis=None):
        if analysis is None:
            self.cursor.execute(''' select doc.surname, doc.name, doc.patronymic, cour.analysis
                                from doctors doc, doctor_analysis cour
                                where cour.doctor = doc.login
                                ''')
            dat = self.cursor.fetchall()
            data = Data(dat, None)
            return data
        if self.__analysisExists__(analysis):
            self.cursor.execute(''' select doc.surname, doc.name, doc.patronymic, cour.analysis
                                from doctors doc, doctor_analysis cour
                                where cour.doctor = doc.login and cour.analysis = '%s'
                                ''' % analysis)
            dat = self.cursor.fetchall()
            data = Data(dat, None)
            return data
        return Data('Analysis does not exist', None)

    def viewDoctorShedule(self):
        try:
            self.cursor.execute(''' select * from doctor_shedule ''')
            dat = self.cursor.fetchall()
            data = Data(dat, None)
            return data
        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def viewAppointmentHistory(self, login):
        try:
            self.cursor.execute(''' select * from appointment_history where patient = '%s' ''' % login)

            dat = self.cursor.fetchall()
            data = Data(dat, None)
            return data
        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def makeAppointment(self, time, doctor, login):
        try:
            self.cursor.execute(
                ''' insert into appointment_history values ('%s', '%s', '%s') ''' % (doctor, time, login))
            # self.conn.commit()
            return Data('Appointment was successful', None)
        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def cancelAppointment(self, time, doctor, login):
        try:
            self.cursor.execute(
                ''' delete from appointment_history where time = '%s' and doctor = '%s' and login = '%s' ''' % (
                time, doctor, login))
            self.conn.commit()
            return Data('Appointment was cancel', None)
        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def changePassword(self, login, newPassword):
        if not newPassword.isalnum():
            return Data('Incorrect format', None)

        self.cursor.execute(''' update account set password='%s' where login='%s' ''' % (newPassword, login))
        self.conn.commit()
        return Data('Changed!', None)


    def __areaExists__(self, area_name):
        self.cursor.execute(''' select area from areas where area='%s' ''' % area_name)
        return True if self.cursor.fetchone() else False

    def __analysisExists__(self, analysis):
        self.cursor.execute(''' select analysis from analyzes where analysis='%s' ''' % analysis)
        return True if self.cursor.fetchone() else False


class Administrator:

    def __init__(self, dbname, username):
        self.conn = psycopg2.connect(dbname=dbname, user=username,
                                     password='', host='localhost')

        self.cursor = self.conn.cursor()

    def checkUser(self, login, passwd):
        self.cursor.execute(''' select password from account
                            where login = '%s' and status = 'admin' '''
                            % login)

        password = self.cursor.fetchone()
        return False if (password is None or password[0] != passwd) else True

    def addDoctor(self, names, login, password, analyzes):
        try:
            if login.isalnum() and password.isalnum():
                self.__createDoctorAccount__(login, password)
                self.cursor.execute(''' 
                                    insert into doctors values ('%s', '%s', '%s', '%s') 
                                    ''' % (login, names[0], names[1], names[2]))

                self.__setDoctorAnalysis__(login, analyzes)
                self.conn.commit()
                return Data('Doctor was successfully added', None)
            return Data('Incorrect login or password format', None)


        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def changePatientArea(self, login, newArea):
        try:
            if not self.__patientExists__(login) and not self.__areaExists__(newArea):
                return Data('Incorrect data!', None)

            self.cursor.execute(''' update area_list set area='%s' where patient='%s' ''' % (newArea, login))
            self.cursor.execute(''' update results set area='%s' where patient='%s' ''' % (newArea, login))
            self.conn.commit()
            return Data('Replaced', None)


        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def renameArea(self, oldArea, newArea):
        try:
            if not self.__areaExists__(oldArea) and not self.__areaExists__(newArea):
                return Data('Incorrect data!', None)

            self.cursor.execute(''' insert into areas values 
                                ('%s', (select class_doctor from doctors where area = '%s')) '''
                                % (newArea, oldArea))

            self.cursor.execute(''' update area_list set area='%s' where area='%s' ''' % (newArea, oldArea))
            self.cursor.execute(''' update results set area='%s' where area='%s' ''' % (newArea, oldArea))
            self.cursor.execute(''' delete from areas values where area='%s' ''' % oldArea)
            self.conn.commit()
            return Data('Replaced', None)

        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def addPatient(self, names, login, password, area_name):
        try:
            if login.isalnum() and password.isalnum():
                self.__createPatientAccount__(login, password)
                self.cursor.execute(''' 
                                    insert into patients values ('%s', '%s', '%s', '%s') 
                                    ''' % (login, names[0], names[1], names[2]))
                self.__addToArea__(login, area_name)
                self.conn.commit()
                return Data('Patient was successfully added', None)


            return Data('Incorrect login or password format', None)


        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def addDoctorAnalisys(self, doctor, analysis):
        try:
            if self.__isDoctorAnalysis__(doctor, analysis):
                return Data('Already exist', None)

            self.cursor.execute('''
                                insert into doctor_analysis (doctor, analysis) values ('%s', '%s') 
                                ''' % (doctor, analysis))
            self.conn.commit()
            return Data('Inserted', None)

        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def addAnalysis(self, analysis):
        try:
            self.cursor.execute(''' insert into analyzes values ('%s') ''' % analysis)
            self.conn.commit()
            return Data('Created new analysis', None)


        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def addArea(self, area_name, area_doctor):
        try:
            if area_name.isalnum():
                self.cursor.execute(''' 
                                    insert into areas values ('%s', '%s') 
                                    ''' % (area_name, area_doctor))
                self.conn.commit()
                return Data('New area created', None)


            return Data('Incorrect area name', None)


        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def changePassword(self, login, newPassword):
        if not newPassword.isalnum():
            return Data('Incorrect format', None)

        self.cursor.execute(''' update account set password='%s' where login='%s' ''' % (newPassword, login))
        self.conn.commit()
        return Data('Changed!', None)


    def setPatientArea(self, login, area_name):
        self.cursor.execute(''' update table area_list set area = '%s'
                            where patient = '%s' '''
                            % (area_name, login))
        self.conn.commit()
        return Data('Patient area updated!', None)


    def removePatient(self, login, dependencies):
        try:
            if not self.__patientExists__(login):
                return Data('Unknown patient', None)

            if dependencies.isnumeric() and int(dependencies) == 1:
                self.cursor.execute(''' delete from results where patient='%s' ''' % login)
                self.cursor.execute(''' delete from area_list where patient='%s' ''' % login)
                self.cursor.execute(''' delete from patients where login='%s' ''' % login)
                self.conn.commit()
                return Data('Patient deleted!', None)

            elif dependencies.isnumeric() and int(dependencies) == 0:
                self.cursor.execute(''' delete from patients where login = '%s' ''' % login)

                return Data('Patient deleted!', None)
            return Data('Incorrect data', None)


        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def removeDoctor(self, login, dependencies):
        try:
            if not self.__doctorExists__(login):
                return Data('Unknown doctor', None)

            if dependencies.isnumeric() and int(dependencies) == 1:
                self.cursor.execute(''' delete from doctor_analysis where doctor = '%s' ''' % login)
                self.cursor.execute(''' update areas set class_doctor = null where class_doctor = '%s' ''' % login)
                self.cursor.execute(''' delete from doctors where login = '%s' ''' % login)
                self.conn.commit()

            elif dependencies.isnumeric() and int(dependencies) == 0:
                self.cursor.execute(''' delete from doctors where login = '%s' ''' % login)
                self.conn.commit()
            return Data('Removed!', None)


        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def removePatientFromArea(self, login):
        self.cursor.execute(''' delete from area_list where patient = '%s' ''' % login)
        self.cursor.execute(''' delete from results where patient = '%s' ''' % login)
        self.conn.commit()
        return Data('Removed!', None)

    def removeDoctorAnalysis(self, doctor, analysis):
        self.cursor.execute(
            ''' delete from doctor_analysis where doctor = '%s' and analysis = '%s' ''' % (doctor, analysis))
        self.conn.commit()
        return Data('Removed!', None)

    def removeArea(self, area_name, dependencies):
        try:
            if dependencies.isnumeric() and int(dependencies) == 1:
                self.cursor.execute(''' delete from area_list where area='%s' ''' % area_name)
                self.cursor.execute(''' delete from results where area='%s' ''' % area_name)
                self.cursor.execute(''' delete from areas where area = '%s' ''' % area_name)
                self.conn.commit()
            elif dependencies.isnumeric() and int(dependencies) == 0:
                self.cursor.execute(''' delete from areas where area = '%s' ''' % area_name)
                self.conn.commit()
            return Data('Removed!', None)

        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def removeAnalysis(self, analysis, dependencies):
        try:
            if not self.__analysisExists__(analysis):
                return Data('Unknown analysis', None)

            if dependencies.isnumeric() and int(dependencies) == 1:
                self.cursor.execute(''' delete from results where analysis='%s' ''' % analysis)
                self.cursor.execute(''' delete from doctor_analysis where analysis='%s' ''' % analysis)
                self.cursor.execute(''' delete from analyzes where analysis = '%s' ''' % analysis)
                self.conn.commit()

            elif dependencies.isnumeric() and int(dependencies) == 0:
                self.cursor.execute(''' delete from analyzes where analysis='%s' ''' % analysis)
                self.conn.commit()
            return Data('Removed!', None)

        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def removeResults(self, area_name):
        try:
            if not self.__areaExists__(area_name):
                return Data('Unknown area', None)

            self.cursor.execute(''' delete from results where area='%s' ''' % area_name)
            self.conn.commit()
            return Data('Removed!', None)

        except psycopg2.DatabaseError as db_error:
            self.conn.commit()
            return db_error

    def updateDoctorInfo(self, names, login):
        if self.__doctorExists__(login):
            self.cursor.execute(''' update table doctors
                                set surname = '%s', name = '%s', patronymic = '%s' 
                                where login = '%s' '''
                                % (names[0], names[1], names[2], login))
            self.conn.commit()
            return Data('Updated!', None)

        return Data('Unknown doctor!', None)


    def updatePatientInfo(self, names, login):
        if self.__patientExists__(login):
            self.cursor.execute(''' update table patients
                                set surname = '%s', name = '%s', patronymic = '%s' 
                                where login = '%s' '''
                                % (names[0], names[1], names[2], login))
            self.conn.commit()
            return Data('Updated!', None)

        return Data('Unknown patient!', None)

    def updateDoctorShedule(self, names, login, time, state):
        if self.__doctorExists__(login):
            self.cursor.execute(''' update table doctor_shedule
                                set state = '%s'
                                where doctor = '%s' and time = '%s' '''
                                % (state, names[0], time))
            self.conn.commit()
            return Data('Updated!', None)
        return Data('Unknown doctor!', None)

    def __createDoctorAccount__(self, login, password):
        self.cursor.execute(''' 
                            insert into account values ('%s', '%s', 'doctor') 
                            ''' % (login, password))

    def __setDoctorAnalysis__(self, doctor, analysis):
        for i in range(0, len(analysis)):
            self.cursor.execute('''
                                insert into doctor_analysis (doctor, analysis) values ('%s', '%s') 
                                ''' % (doctor, analysis[i]))

    def __isDoctorAnalysis__(self, doctor, analysis):
        self.cursor.execute(
            ''' select true from doctor_analysis where doctor='%s' and analysis='%s' ''' % (doctor, analysis))
        return True if self.cursor.fetchall() else False

    def __patientExists__(self, patient):
        self.cursor.execute(''' select login from patients where login='%s' ''' % patient)
        return True if self.cursor.fetchone() else False

    def __doctorExists__(self, login):
        self.cursor.execute(''' select login from doctors where login='%s' ''' % login)
        return True if self.cursor.fetchone() else False

    def __areaExists__(self, area_name):
        self.cursor.execute(''' select area from areas where area='%s' ''' % area_name)
        return True if self.cursor.fetchone() else False

    def __analysisExists__(self, analysis):
        self.cursor.execute(''' select analysis from analyzes where analysis='%s' ''' % analysis)
        return True if self.cursor.fetchone() else False

    def __createPatientAccount__(self, login, password):
        self.cursor.execute(''' insert into account values ('%s', '%s', 'patient') ''' % (login, password))
        return 'Patient account created'

    def __addToArea__(self, patient_login, area_name):
        self.cursor.execute(''' insert into area_list values ('%s', '%s') ''' % (patient_login, area_name))
        return 'Patient was successfully added to the area'
